package com.app.dao;

import java.util.List;

import com.app.pojos.Topic;

public interface ITopicDao {
	List<Topic> getAllTopics();
}
