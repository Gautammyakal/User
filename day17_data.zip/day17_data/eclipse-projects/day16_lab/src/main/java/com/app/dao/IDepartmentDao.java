package com.app.dao;

import java.util.List;

public interface IDepartmentDao {
// add a method to ret all dept names
	List<String> getAllDepartments();
}
